<body bgcolor="black" text="White">
<?php
echo "MCA";
?>
<h1>MCA</h1>
</body>