<?php
$bcol=$_REQUEST["bcol"];
$fcol=$_REQUEST["fcol"];
//echo $col;
?>
<body bgcolor="<?php echo $bcol;?>" text="<?php echo $fcol;?>">
<h1>TEST</h1>
</body>