<?php
$col=$_REQUEST["col"];
//echo $col;
?>
<body bgcolor="<?php echo $col;?>">
</body>