<?php
//header("location:https://www.smsvaranasi.com");
header("location:pf12.php");
?>