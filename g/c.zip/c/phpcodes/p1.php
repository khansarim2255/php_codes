<?php
$num1=20;
$num2=30;
echo "Addition is: :".($num1+$num2);
?>